//Global
var removeLimit = $(window).outerHeight() / 2,
    moreOptionContent = $('.more-option-content'),
    pos = $(window).scrollTop(), // For scrolling direction
    options = {
        root: document.documentElement.body,
        rootMargin: '0px',
        threshold: 1.0
    };


//Global utilities
function scrollDirection() {
    var scroll = $(window).scrollTop(),
        scrollDirection = "";
    if (scroll > pos) {
        scrollDirection = "down";
    } else {
        scrollDirection = "up";
    }
    pos = $(window).scrollTop();
    return scrollDirection;

};

function menuClick() {
    $('.more-icon').click(function (e) {
        moreOptionContent.addClass('menu-active');
        $('.more-option-dvd').addClass('nav-is-active');
    })
}

function section2() {
    $('.section-2').css({
        "transform": "translateY(" + $(window).scrollTop() * -0.3 + "px)"
    })
}

function section3() {
    $('.section-3').css({
        "transform": "translateY(" + $(window).scrollTop() * -0.1 + "px)"
    })
}

function section3Sub() {
    $('.section-3-sub').css({
        "transform": "translateY(" + ($(window).scrollTop()) * -0.05 + "px)"
    })

}

function section4() {
    $('.section-4').css({
        "transform": "translateY(" + $(window).scrollTop() * -0.02 + "px)"
    })
}

function section5() {
    $('.section-5').css({
        "transform": "translateY(" + $(window).scrollTop() * -0.1 + "px)"
    })
}
function section5Sub() {
    $('.section-5-sub').css({
        "transform": "translateY(" + ($(window).scrollTop() - 200) * -0.05 + "px)"
    })
}

function removeNavAnim() {
    moreOptionContent.addClass('slide-up');
    $('.more-option-dvd').addClass('nav-is-hidden');
    setTimeout(function () {
        moreOptionContent.removeClass('menu-active slide-up');
        $('.more-option-dvd').removeClass('nav-is-active nav-is-hidden');
    }, 1000);
}


function removeNavMenu() {
    if ($(window).scrollTop() > removeLimit && scrollDirection() == "down") {
        removeNavAnim();
    }
}

function closeNavMenu() {
    $('.close').click(function (e) {
        e.preventDefault();
        removeNavAnim();
    })
}

function insersectionFn() {

}

function slidingPanelHeight() {
    var bottomElement = $('.section-3-sub')[0].getBoundingClientRect();
    $('.sliding-panel').css({
        'height': bottomElement.top + bottomElement.height
    })
}

$(document).ready(function () {
    // slidingPanelHeight();
    closeNavMenu();
    insersectionFn(); // Intersection callback function
    /* Scroll animation are added here*/
    $(window).scroll(function () {
        //section2(); // Section-2 slide up like animation.
        //section3(); // Section-3 slide up like animation.
        //section3Sub(); //Sub head
        //section4();// Section 4
        /* Removing the nav menu while scrolling down  */
        removeNavMenu(); //Only when scrolling down. Not on close menu click
        // section5();
        // section5Sub();
    });



    menuClick(); //Nav menu click function
});

$(window).resize(function () {
    removeNavMenu();//Only when scrolling down. Not on close menu click
})

